#!/usr/bin/python
#coding=utf8
"""
# Author: andy
# Created Time : 2017-10-16 15:33:30

# File Name: __init__.py
# Description:

"""
from topicSim import *
